

// let fortuneResults ={
//   money:{
//     stars:["★★★","★★","★"] ,
//     detail:["最高の金運です！いつの間にかお金が溜まっているかも・・・？",
// 						"まずまず金運です！使いすぎには注意しましょう！",
// 						"悪い傾向が見られます！財布の紐は絞めておくと吉です！"]
// 	},
// 	work:{
// 		stars:["★★★","★★","★"] ,
// 		detail:["最高の仕事運です！いつも以上にチャンスが巡ってくるかも・・・？",
// 						"まずまず仕事運です！普段通り仕事が進むでしょう！",
// 						"悪い傾向が見られます！自信過剰にならないように注意しましょう"]
// 	},

// 	health:{
// 		stars:["★★★","★★","★"] ,
// 		detail:["最高の健康運です！ランニングの距離を伸ばしても良いですね！",
// 						"まずまず健康運です！無理せず体を動かしましょう！",
// 					  "悪い傾向が見られます！ケガにご注意を・・・"]
// 	}
// };

let fortuneResults ={
	money:[
		{stars:"★★★", detail:"最高の金運です！いつの間にかお金が溜まっているかも・・・？"},
		{stars:"★★", detail:"まずまず金運です！使いすぎには注意しましょう！"},
		{stars:"★", detail:"悪い傾向が見られます！財布の紐は絞めておくと吉です！"}
	],
	work:[
	{stars:"★★★", detail:"最高の仕事運です！いつも以上にチャンスが巡ってくるかも・・・？"},
	{stars:"★★", detail:"まずまず仕事運です！普段通り仕事が進むでしょう！"},
	{stars:"★", detail:"悪い傾向が見られます！自信過剰にならないように注意しましょう"}
	],
	health:[
		{stars:"★★★", detail:"最高の健康運です！ランニングの距離を伸ばしても良いですね！"},
		{stars:"★★", detail:"まずまず健康運です！無理せず体を動かしましょう！"},
		{stars:"★", detail:"悪い傾向が見られます！ケガにご注意を・・・"}
		]
};

$(function(){

	$(document).on("click",".js-fortune-start",function(){

		for(let key in fortuneResults){
			let num = (Math.floor(Math.random()*3));

			let item_s= fortuneResults[key][num].stars;
			let item_d= fortuneResults[key][num].detail;

			console.log(num);
			console.log(item_s);
			console.log(item_d);
		
			$("."+ key).find(".stars").text(item_s);
			$("."+ key).find(".detail").text(item_d);

		}

		$(".result").fadeToggle("slow").css("transition","0.5s");
		$(".result").css("margin-top","50px").css("display","block");
		$(".js-fortune-start").text("もう一度占う！").toggleClass("js-fortune-start js-fortune-restart");
		})
		

	 $(document).on("click",".js-fortune-restart",function(){
		$(".result").fadeToggle("50").css("transition","");
	 	$(".result").css("margin-top","45px");//.css("display","none");
	  $(".js-fortune-restart").text("運勢を占う！").toggleClass("js-fortune-start js-fortune-restart");
	 })

});


